from app import app, db
from models import SustainablePractice, SustainabilityChallenge, SustainabilityQuest

with app.app_context():
    practices_count = SustainablePractice.query.count()
    challenges_count = SustainabilityChallenge.query.count()
    quests_count = SustainabilityQuest.query.count()
    
    print(f'Practices: {practices_count}')
    print(f'Challenges: {challenges_count}')
    print(f'Quests: {quests_count}')
    
    # Print some details about the first practice
    if practices_count > 0:
        practice = SustainablePractice.query.first()
        print(f'\nFirst practice: {practice.name}')
        print(f'Description: {practice.description[:100]}...')
        print(f'Category: {practice.category}')
        print(f'Points: {practice.points_awarded}')