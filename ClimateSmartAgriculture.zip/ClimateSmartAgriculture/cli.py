"""
Command-line interface for platform administration tasks
"""
import click
from flask.cli import with_appcontext
from app import app, db
from utils.seed_sustainability import run_all_seeding

@click.group()
def cli():
    """CLI for platform administration tasks"""
    pass

@cli.command('seed-db')
@with_appcontext
def seed_db():
    """Seed the database with initial data"""
    click.echo('Seeding database...')
    
    # Add seeding functions here
    run_all_seeding()
    
    click.echo('Database seeding completed!')

@cli.command('reset-db')
@with_appcontext
def reset_db():
    """Reset the database (drop all tables and recreate them)"""
    if click.confirm('Are you sure you want to reset the database? This will delete all data.'):
        click.echo('Resetting database...')
        
        db.drop_all()
        db.create_all()
        
        click.echo('Database reset completed!')
    else:
        click.echo('Database reset cancelled.')

if __name__ == '__main__':
    cli()