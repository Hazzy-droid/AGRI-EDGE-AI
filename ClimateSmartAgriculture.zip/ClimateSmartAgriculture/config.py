import os
import logging

logger = logging.getLogger(__name__)

def init_config(app):
    """Initialize application configuration"""
    
    # API Keys and external service configurations
    app.config['WEATHER_API_KEY'] = os.environ.get('WEATHER_API_KEY', '')
    app.config['SATELLITE_API_KEY'] = os.environ.get('SATELLITE_API_KEY', '')
    app.config['SOIL_API_KEY'] = os.environ.get('SOIL_API_KEY', '')
    
    # Configure Earth Engine API if available
    app.config['GOOGLE_EARTH_ENGINE_ENABLED'] = bool(os.environ.get('GOOGLE_EARTH_ENGINE_ENABLED', False))
    
    # Service Proxy Configuration
    app.config['USE_PROXY_SERVICE'] = os.environ.get('USE_PROXY_SERVICE', 'false').lower() == 'true'
    app.config['SERVICE_PROXY_URL'] = os.environ.get('SERVICE_PROXY_URL', '')
    app.config['SERVICE_PROXY_KEY'] = os.environ.get('SERVICE_PROXY_KEY', '')
    
    # Direct API Configurations
    app.config['PERPLEXITY_API_KEY'] = os.environ.get('PERPLEXITY_API_KEY', '')
    app.config['TWILIO_ACCOUNT_SID'] = os.environ.get('TWILIO_ACCOUNT_SID', '')
    app.config['TWILIO_AUTH_TOKEN'] = os.environ.get('TWILIO_AUTH_TOKEN', '')
    app.config['TWILIO_PHONE_NUMBER'] = os.environ.get('TWILIO_PHONE_NUMBER', '')
    
    # TensorFlow model paths
    app.config['CROP_HEALTH_MODEL_PATH'] = os.environ.get('CROP_HEALTH_MODEL_PATH', 'ai_models/saved_models/crop_health_model')
    app.config['YIELD_PREDICTION_MODEL_PATH'] = os.environ.get('YIELD_PREDICTION_MODEL_PATH', 'ai_models/saved_models/yield_prediction_model')
    app.config['WATER_MANAGEMENT_MODEL_PATH'] = os.environ.get('WATER_MANAGEMENT_MODEL_PATH', 'ai_models/saved_models/water_management_model')
    
    # Cache configuration
    app.config['CACHE_TYPE'] = 'redis' if os.environ.get('REDIS_URL') else 'simple'
    app.config['CACHE_REDIS_URL'] = os.environ.get('REDIS_URL', '')
    
    # Supported languages
    app.config['SUPPORTED_LANGUAGES'] = {
        'en': 'English',
        'fr': 'French',
        'sw': 'Swahili',
        'ha': 'Hausa',
        'yo': 'Yoruba',
        'am': 'Amharic',
        'ar': 'Arabic'
    }
    
    # Default map center (Africa)
    app.config['DEFAULT_MAP_CENTER'] = [0.0, 20.0]
    app.config['DEFAULT_ZOOM_LEVEL'] = 3
    
    # Crop types supported by the platform
    app.config['SUPPORTED_CROPS'] = [
        'maize', 'rice', 'sorghum', 'millet', 'cassava', 
        'yam', 'sweet_potato', 'groundnut', 'cowpea', 'soybean',
        'coffee', 'cocoa', 'cotton', 'tea'
    ]
    
    # Logging configuration
    app.config['LOG_TO_FILE'] = bool(os.environ.get('LOG_TO_FILE', False))
    
    logger.info("Application configuration loaded")
    
    return app
