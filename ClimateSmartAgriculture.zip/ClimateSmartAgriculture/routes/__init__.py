# Empty __init__.py file to make the routes directory a Python package
