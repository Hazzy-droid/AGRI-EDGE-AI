from datetime import datetime
from app import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    phone = db.Column(db.String(20))  # Phone number for SMS notifications
    language = db.Column(db.String(10), default='en')
    farm_name = db.Column(db.String(100))
    location = db.Column(db.String(100))
    farm_size = db.Column(db.Float)  # in hectares
    
    # Gamification attributes
    learning_points = db.Column(db.Integer, default=0)  # Points from learning activities
    farming_points = db.Column(db.Integer, default=0)  # Points from applying techniques
    community_points = db.Column(db.Integer, default=0)  # Points from community participation
    total_points = db.Column(db.Integer, default=0)  # Sum of all points types
    level = db.Column(db.Integer, default=1)  # User's current level in the platform
    
    is_admin = db.Column(db.Boolean, default=False)  # Admin flag for access control
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    farms = db.relationship('Farm', backref='owner', lazy=True)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Farm(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100))
    size = db.Column(db.Float)  # in hectares
    coordinates = db.Column(db.String(100))  # lat,long format
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    crops = db.relationship('Crop', backref='farm', lazy=True)
    soil_data = db.relationship('SoilData', backref='farm', lazy=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Farm {self.name}>'

class Crop(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    variety = db.Column(db.String(100))
    planting_date = db.Column(db.DateTime)
    expected_harvest_date = db.Column(db.DateTime)
    area = db.Column(db.Float)  # in hectares
    farm_id = db.Column(db.Integer, db.ForeignKey('farm.id'), nullable=False)
    health_records = db.relationship('CropHealth', backref='crop', lazy=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Crop {self.name} at Farm {self.farm_id}>'

class CropHealth(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    crop_id = db.Column(db.Integer, db.ForeignKey('crop.id'), nullable=False)
    ndvi_value = db.Column(db.Float)  # Normalized Difference Vegetation Index
    health_status = db.Column(db.String(50))  # Good, Fair, Poor
    issues = db.Column(db.String(200))  # Detected issues
    date_recorded = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<CropHealth {self.health_status} for Crop {self.crop_id}>'

class SoilData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    farm_id = db.Column(db.Integer, db.ForeignKey('farm.id'), nullable=False)
    moisture = db.Column(db.Float)  # percentage
    temperature = db.Column(db.Float)  # celsius
    ph = db.Column(db.Float)
    electrical_conductivity = db.Column(db.Float)  # dS/m
    nitrogen = db.Column(db.Float)  # ppm
    phosphorus = db.Column(db.Float)  # ppm
    potassium = db.Column(db.Float)  # ppm
    sensor_id = db.Column(db.String(100))
    coordinates = db.Column(db.String(100))  # lat,long format
    date_recorded = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SoilData for Farm {self.farm_id} at {self.date_recorded}>'

class WeatherData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    location = db.Column(db.String(100))
    coordinates = db.Column(db.String(100))  # lat,long format
    temperature = db.Column(db.Float)  # celsius
    humidity = db.Column(db.Float)  # percentage
    precipitation = db.Column(db.Float)  # mm
    wind_speed = db.Column(db.Float)  # m/s
    forecast_type = db.Column(db.String(50))  # current, hourly, daily
    forecast_time = db.Column(db.DateTime)
    date_recorded = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<WeatherData for {self.location} at {self.forecast_time}>'

class Recommendation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    farm_id = db.Column(db.Integer, db.ForeignKey('farm.id'), nullable=False)
    crop_id = db.Column(db.Integer, db.ForeignKey('crop.id'))
    category = db.Column(db.String(50))  # irrigation, fertilization, pest control, etc.
    description = db.Column(db.Text, nullable=False)
    priority = db.Column(db.String(20))  # high, medium, low
    status = db.Column(db.String(20), default='pending')  # pending, implemented, ignored
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Recommendation {self.category} for Farm {self.farm_id}>'

class SatelliteImage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    farm_id = db.Column(db.Integer, db.ForeignKey('farm.id'), nullable=False)
    image_date = db.Column(db.DateTime, nullable=False)
    image_type = db.Column(db.String(50))  # RGB, multi-spectral, etc.
    cloud_coverage = db.Column(db.Float)  # percentage
    source = db.Column(db.String(100))  # Sentinel, Landsat, etc.
    processed = db.Column(db.Boolean, default=False)
    url = db.Column(db.String(255))  # URL to the image if stored externally
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SatelliteImage {self.image_type} for Farm {self.farm_id} on {self.image_date}>'
        
# Community features - Farmer social networking

class CommunityPost(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(255))
    category = db.Column(db.String(50))  # knowledge_sharing, question, market, event, success_story
    location = db.Column(db.String(100))
    visibility = db.Column(db.String(20), default='public')  # public, region, private
    likes = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('posts', lazy=True))
    comments = db.relationship('PostComment', backref='post', lazy=True, cascade='all, delete-orphan')
    tags = db.relationship('PostTag', backref='post', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<CommunityPost {self.title} by User {self.user_id}>'

class PostComment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('community_post.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    likes = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('comments', lazy=True))
    
    def __repr__(self):
        return f'<PostComment by User {self.user_id} on Post {self.post_id}>'

class PostTag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('community_post.id'), nullable=False)
    tag_name = db.Column(db.String(50), nullable=False)
    
    def __repr__(self):
        return f'<PostTag {self.tag_name} for Post {self.post_id}>'

class FarmerFollower(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    followed_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<FarmerFollower {self.follower_id} follows {self.followed_id}>'

class FarmerMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    sender = db.relationship('User', foreign_keys=[sender_id], backref=db.backref('sent_messages', lazy=True))
    recipient = db.relationship('User', foreign_keys=[recipient_id], backref=db.backref('received_messages', lazy=True))
    
    def __repr__(self):
        return f'<FarmerMessage from {self.sender_id} to {self.recipient_id}>'

class MarketplaceItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50))  # equipment, seeds, produce, service
    price = db.Column(db.Float)
    currency = db.Column(db.String(10), default='KES')
    location = db.Column(db.String(100))
    image_url = db.Column(db.String(255))
    status = db.Column(db.String(20), default='available')  # available, pending, sold
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('marketplace_items', lazy=True))
    
    def __repr__(self):
        return f'<MarketplaceItem {self.title} by User {self.user_id}>'
        
# Gamified Learning Module Models

class LearningModule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50))  # soil_management, water_conservation, etc.
    difficulty_level = db.Column(db.Integer)  # 1-5 scale
    points_available = db.Column(db.Integer, default=100)
    estimated_duration = db.Column(db.Integer)  # in minutes
    prerequisites = db.Column(db.String(255))  # comma-separated list of module IDs
    image_url = db.Column(db.String(255))
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    lessons = db.relationship('LearningLesson', backref='module', lazy=True, cascade='all, delete-orphan')
    quizzes = db.relationship('LearningQuiz', backref='module', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<LearningModule {self.title}>'

class LearningLesson(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    module_id = db.Column(db.Integer, db.ForeignKey('learning_module.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    order_index = db.Column(db.Integer, nullable=False)  # Sequence within the module
    media_type = db.Column(db.String(50), default='text')  # text, video, infographic
    media_url = db.Column(db.String(255))
    points_awarded = db.Column(db.Integer, default=10)  # Points for completing this lesson
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<LearningLesson {self.title} in Module {self.module_id}>'

class LearningQuiz(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    module_id = db.Column(db.Integer, db.ForeignKey('learning_module.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    order_index = db.Column(db.Integer, nullable=False)  # Sequence within the module
    passing_score = db.Column(db.Integer, default=70)  # Percentage needed to pass
    points_awarded = db.Column(db.Integer, default=50)  # Points for passing this quiz
    time_limit = db.Column(db.Integer)  # in minutes, NULL means no time limit
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    questions = db.relationship('QuizQuestion', backref='quiz', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<LearningQuiz {self.title} in Module {self.module_id}>'

class QuizQuestion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('learning_quiz.id'), nullable=False)
    question_text = db.Column(db.Text, nullable=False)
    question_type = db.Column(db.String(50), default='multiple_choice')  # multiple_choice, true_false, short_answer
    order_index = db.Column(db.Integer, nullable=False)  # Sequence within the quiz
    points = db.Column(db.Integer, default=10)  # Points for this individual question
    
    # Relationships
    choices = db.relationship('QuestionChoice', backref='question', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<QuizQuestion #{self.order_index} in Quiz {self.quiz_id}>'

class QuestionChoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('quiz_question.id'), nullable=False)
    choice_text = db.Column(db.Text, nullable=False)
    is_correct = db.Column(db.Boolean, default=False)
    explanation = db.Column(db.Text)  # Explanation for why this is/isn't correct
    
    def __repr__(self):
        return f'<QuestionChoice for Question {self.question_id}, Correct: {self.is_correct}>'

class UserAchievement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    achievement_id = db.Column(db.Integer, db.ForeignKey('achievement.id'), nullable=False)
    date_earned = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('achievements', lazy=True))
    achievement = db.relationship('Achievement', backref=db.backref('users', lazy=True))
    
    def __repr__(self):
        return f'<UserAchievement User {self.user_id}, Achievement {self.achievement_id}>'

class Achievement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50))  # learning, farming, community, marketplace
    points_awarded = db.Column(db.Integer, default=100)
    badge_image_url = db.Column(db.String(255))
    criteria = db.Column(db.Text)  # Description of how to earn this achievement
    is_hidden = db.Column(db.Boolean, default=False)  # If true, hidden until earned
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Achievement {self.name}>'

class UserLearningProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    module_id = db.Column(db.Integer, db.ForeignKey('learning_module.id'), nullable=False)
    lessons_completed = db.Column(db.Text)  # Comma-separated list of completed lesson IDs
    current_lesson_id = db.Column(db.Integer, db.ForeignKey('learning_lesson.id'))
    quizzes_completed = db.Column(db.Text)  # Comma-separated list of completed quiz IDs
    points_earned = db.Column(db.Integer, default=0)
    completion_date = db.Column(db.DateTime)  # NULL if not completed
    last_activity_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('learning_progress', lazy=True))
    module = db.relationship('LearningModule', backref=db.backref('user_progress', lazy=True))
    current_lesson = db.relationship('LearningLesson')
    
    def __repr__(self):
        return f'<UserLearningProgress User {self.user_id}, Module {self.module_id}>'

class QuizAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey('learning_quiz.id'), nullable=False)
    score = db.Column(db.Integer)  # Score as a percentage (0-100)
    passed = db.Column(db.Boolean, default=False)
    time_spent = db.Column(db.Integer)  # in seconds
    attempt_number = db.Column(db.Integer, default=1)
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('quiz_attempts', lazy=True))
    quiz = db.relationship('LearningQuiz', backref=db.backref('attempts', lazy=True))
    answers = db.relationship('QuizAnswer', backref='attempt', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<QuizAttempt User {self.user_id}, Quiz {self.quiz_id}, Score {self.score}>'

class QuizAnswer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    attempt_id = db.Column(db.Integer, db.ForeignKey('quiz_attempt.id'), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey('quiz_question.id'), nullable=False)
    selected_choice_id = db.Column(db.Integer, db.ForeignKey('question_choice.id'))
    text_answer = db.Column(db.Text)  # For short answer questions
    is_correct = db.Column(db.Boolean, default=False)
    points_earned = db.Column(db.Integer, default=0)
    
    # Relationships
    question = db.relationship('QuizQuestion')
    selected_choice = db.relationship('QuestionChoice')
    
    def __repr__(self):
        return f'<QuizAnswer Attempt {self.attempt_id}, Question {self.question_id}>'

# Sustainable Farming Gamification Models

class SustainablePractice(db.Model):
    """Sustainable farming practices that users can learn and implement"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)  # soil, water, biodiversity, energy, waste
    difficulty = db.Column(db.Integer)  # 1-5 scale
    impact_level = db.Column(db.Integer)  # 1-5 scale (environmental impact)
    points_awarded = db.Column(db.Integer, default=50)
    implementation_guide = db.Column(db.Text)  # How-to instructions
    image_url = db.Column(db.String(255))
    verification_method = db.Column(db.String(100))  # How practice is verified (photo, sensor data, etc.)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    active = db.Column(db.Boolean, default=True)
    
    # Relationships
    prerequisites = db.relationship('PracticePrerequisite', 
                                   foreign_keys='PracticePrerequisite.practice_id',
                                   backref='required_for', 
                                   lazy='dynamic')
    required_by = db.relationship('PracticePrerequisite', 
                                 foreign_keys='PracticePrerequisite.prerequisite_id',
                                 backref='prerequisite_for', 
                                 lazy='dynamic')
    
    def __repr__(self):
        return f'<SustainablePractice {self.name}>'

class PracticePrerequisite(db.Model):
    """Prerequisites for implementing sustainable practices"""
    id = db.Column(db.Integer, primary_key=True)
    practice_id = db.Column(db.Integer, db.ForeignKey('sustainable_practice.id'), nullable=False)
    prerequisite_id = db.Column(db.Integer, db.ForeignKey('sustainable_practice.id'), nullable=False)
    
    def __repr__(self):
        return f'<PracticePrerequisite {self.prerequisite_id} required for {self.practice_id}>'

class UserPractice(db.Model):
    """Records which sustainable practices a user has learned and implemented"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    practice_id = db.Column(db.Integer, db.ForeignKey('sustainable_practice.id'), nullable=False)
    status = db.Column(db.String(20))  # learning, implementing, completed, verified
    implementation_date = db.Column(db.DateTime)
    verification_date = db.Column(db.DateTime)
    verification_evidence = db.Column(db.String(255))  # URL to evidence (photo, data file)
    notes = db.Column(db.Text)
    points_earned = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('sustainable_practices', lazy=True))
    practice = db.relationship('SustainablePractice', backref=db.backref('user_implementations', lazy=True))
    
    def __repr__(self):
        return f'<UserPractice User {self.user_id}, Practice {self.practice_id}, Status {self.status}>'

class SustainabilityChallenge(db.Model):
    """Time-bound challenges for users to implement sustainable practices"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50))  # individual, community, regional, seasonal
    difficulty = db.Column(db.Integer)  # 1-5 scale
    points_awarded = db.Column(db.Integer, default=200)
    badge_awarded = db.Column(db.Integer, db.ForeignKey('achievement.id'))
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=False)
    image_url = db.Column(db.String(255))
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    required_practices = db.relationship('ChallengePractice', backref='challenge', lazy=True)
    badge = db.relationship('Achievement')
    
    def __repr__(self):
        return f'<SustainabilityChallenge {self.title}>'

class ChallengePractice(db.Model):
    """Links challenges to the required sustainable practices"""
    id = db.Column(db.Integer, primary_key=True)
    challenge_id = db.Column(db.Integer, db.ForeignKey('sustainability_challenge.id'), nullable=False)
    practice_id = db.Column(db.Integer, db.ForeignKey('sustainable_practice.id'), nullable=False)
    
    # Relationship
    practice = db.relationship('SustainablePractice')
    
    def __repr__(self):
        return f'<ChallengePractice Challenge {self.challenge_id}, Practice {self.practice_id}>'

class UserChallenge(db.Model):
    """Records which challenges a user has joined and completed"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    challenge_id = db.Column(db.Integer, db.ForeignKey('sustainability_challenge.id'), nullable=False)
    status = db.Column(db.String(20), default='joined')  # joined, in_progress, completed, verified
    progress_percentage = db.Column(db.Integer, default=0)
    completion_date = db.Column(db.DateTime)
    points_earned = db.Column(db.Integer, default=0)
    badge_earned = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('challenges', lazy=True))
    challenge = db.relationship('SustainabilityChallenge', backref=db.backref('participants', lazy=True))
    
    def __repr__(self):
        return f'<UserChallenge User {self.user_id}, Challenge {self.challenge_id}, Status {self.status}>'

class SustainabilityQuest(db.Model):
    """Multi-step quests related to sustainable farming practices"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50))  # beginner, intermediate, advanced
    points_awarded = db.Column(db.Integer, default=300)
    badge_awarded = db.Column(db.Integer, db.ForeignKey('achievement.id'))
    time_limit_days = db.Column(db.Integer)  # NULL means no time limit
    image_url = db.Column(db.String(255))
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    steps = db.relationship('QuestStep', backref='quest', lazy=True, order_by='QuestStep.step_number')
    badge = db.relationship('Achievement')
    
    def __repr__(self):
        return f'<SustainabilityQuest {self.title}>'

class QuestStep(db.Model):
    """Steps required to complete a sustainability quest"""
    id = db.Column(db.Integer, primary_key=True)
    quest_id = db.Column(db.Integer, db.ForeignKey('sustainability_quest.id'), nullable=False)
    step_number = db.Column(db.Integer, nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    step_type = db.Column(db.String(50))  # learn, implement, verify, collaborate
    practice_id = db.Column(db.Integer, db.ForeignKey('sustainable_practice.id'))
    module_id = db.Column(db.Integer, db.ForeignKey('learning_module.id'))
    points_awarded = db.Column(db.Integer, default=50)
    verification_required = db.Column(db.Boolean, default=False)
    verification_method = db.Column(db.String(100))
    
    # Relationships
    practice = db.relationship('SustainablePractice')
    module = db.relationship('LearningModule')
    
    def __repr__(self):
        return f'<QuestStep {self.step_number} for Quest {self.quest_id}>'

class UserQuest(db.Model):
    """Records which quests a user has started and completed"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    quest_id = db.Column(db.Integer, db.ForeignKey('sustainability_quest.id'), nullable=False)
    status = db.Column(db.String(20), default='started')  # started, in_progress, completed
    current_step = db.Column(db.Integer, default=1)
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    completion_date = db.Column(db.DateTime)
    points_earned = db.Column(db.Integer, default=0)
    badge_earned = db.Column(db.Boolean, default=False)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('quests', lazy=True))
    quest = db.relationship('SustainabilityQuest', backref=db.backref('participants', lazy=True))
    steps_progress = db.relationship('UserQuestStep', backref='user_quest', lazy=True)
    
    def __repr__(self):
        return f'<UserQuest User {self.user_id}, Quest {self.quest_id}, Status {self.status}>'

class UserQuestStep(db.Model):
    """Records a user's progress on individual quest steps"""
    id = db.Column(db.Integer, primary_key=True)
    user_quest_id = db.Column(db.Integer, db.ForeignKey('user_quest.id'), nullable=False)
    step_id = db.Column(db.Integer, db.ForeignKey('quest_step.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, in_progress, completed, verified
    completion_date = db.Column(db.DateTime)
    verification_evidence = db.Column(db.String(255))
    points_earned = db.Column(db.Integer, default=0)
    
    # Relationships
    step = db.relationship('QuestStep')
    
    def __repr__(self):
        return f'<UserQuestStep UserQuest {self.user_quest_id}, Step {self.step_id}, Status {self.status}>'

# Alias for compatibility with routes
UserQuestProgress = UserQuestStep

class UserSustainablePractice(db.Model):
    """Records a user's implemented sustainable practices"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    practice_id = db.Column(db.Integer, db.ForeignKey('sustainable_practice.id'), nullable=False)
    status = db.Column(db.String(20), default='implemented')  # implemented, verified, rejected
    implementation_date = db.Column(db.DateTime, default=datetime.utcnow)
    verification_date = db.Column(db.DateTime)
    verification_notes = db.Column(db.Text)
    notes = db.Column(db.Text)
    evidence_url = db.Column(db.String(255))
    
    # Geographic information for the implemented practice
    farm_area_name = db.Column(db.String(100))  # Name/identifier for the area (e.g., "North Field")
    latitude = db.Column(db.Float)  # Center point latitude
    longitude = db.Column(db.Float)  # Center point longitude
    area_size = db.Column(db.Float)  # Size in hectares 
    area_polygon = db.Column(db.Text)  # GeoJSON for precise area boundary
    
    # Implementation details and impact tracking
    resources_used = db.Column(db.Text)  # Resources/materials used for implementation
    cost = db.Column(db.Float)  # Cost of implementation in local currency
    labor_hours = db.Column(db.Float)  # Labor hours spent on implementation
    impact_observations = db.Column(db.Text)  # Observed impacts since implementation
    impact_images = db.Column(db.Text)  # JSON array of image URLs showing implementation/results
    
    # Carbon impact estimations
    carbon_sequestered = db.Column(db.Float)  # Estimated carbon sequestered in kg CO2e
    carbon_methodology = db.Column(db.String(100))  # Methodology used for carbon calculation
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('implemented_practices', lazy=True))
    practice = db.relationship('SustainablePractice', backref=db.backref('implementations', lazy=True))
    
    def __repr__(self):
        return f'<UserSustainablePractice User {self.user_id}, Practice {self.practice_id}, Status {self.status}>'
        
    def get_impact_images(self):
        """Return the list of impact images if available"""
        if not self.impact_images:
            return []
        try:
            import json
            return json.loads(self.impact_images)
        except:
            return []
            
    def get_area_polygon(self):
        """Return the GeoJSON polygon if available"""
        if not self.area_polygon:
            return None
        try:
            import json
            return json.loads(self.area_polygon)
        except:
            return None
            
    def calculate_carbon_impact(self):
        """Calculate estimated carbon impact based on practice type and area"""
        if not self.practice or not self.area_size:
            return None
            
        # Simple estimation based on practice type and area
        # Real implementation would use more sophisticated models
        impact_factors = {
            'soil': 0.5,  # 0.5 tons CO2e per hectare per year for soil practices
            'water': 0.2,  # 0.2 tons CO2e per hectare per year for water practices
            'biodiversity': 0.8,  # 0.8 tons CO2e per hectare per year for biodiversity practices
            'integrated': 1.0,  # 1.0 tons CO2e per hectare per year for integrated practices
            'climate': 1.2,  # 1.2 tons CO2e per hectare per year for climate practices
        }
        
        factor = impact_factors.get(self.practice.category, 0.5)
        
        # Convert to kg (tons * 1000)
        self.carbon_sequestered = self.area_size * factor * 1000
        self.carbon_methodology = 'Basic estimation based on practice category and area'
        return self.carbon_sequestered

# UserChallenge already defined above
